भारत स्वाभिमान – Android APK Build Project

इस पैकेज में Android WebView ऐप का सोर्स कोड है। यह अभी APK नहीं है।
APK GitHub Actions से मुफ्त में बनाया जाएगा।

मोबाइल से अपलोड करने के चरण:
1. ZIP को Extract करें।
2. अपने GitHub repository Bharat-Swabhiman-Trust- में जाएं।
3. Add file > Upload files चुनें।
4. इस ZIP के अंदर की सभी फाइलें और .github फोल्डर का workflow भी repository के root में अपलोड करें।
   जरूरी: .github/workflows/build-apk.yml का path बिल्कुल यही होना चाहिए।
5. Commit changes करें।
6. Repository > Actions खोलें।
7. 'Build Bharat Swabhiman APK' workflow run खोलें।
8. हरा टिक आने पर नीचे Artifacts में Bharat-Swabhiman-Android-APK.zip डाउनलोड करें।
9. ZIP extract करके app-debug.apk फोन में इंस्टॉल करें।

ऐप पैकेज:
- Package ID: com.bharatswabhiman.app
- App name: भारत स्वाभिमान
- Minimum Android: Android 6.0 (API 23)
- Admin demo PIN: 2580

महत्वपूर्ण सीमाएं:
- यह शुरुआती टेस्ट APK है; पोस्टर लोकल ब्राउज़र/ऐप स्टोरेज में सेव होंगे, सभी यूजर्स के बीच साझा नहीं होंगे।
- PIN क्लाइंट-साइड डेमो है, सुरक्षित authentication नहीं। सार्वजनिक उपयोग से पहले backend, secure admin roles, shared image storage और access rules जरूरी हैं।
- ऐप में फिलहाल न्यास का वास्तविक आधिकारिक लोगो नहीं है; placeholder ॐ आइकन है।

लोगो अपडेट: आपके भेजे हुए पोस्टर से गोलाकार ॐ-योग लोगो निकालकर ऐप हेडर और PWA आइकन में लगाया गया है।

ऐप के सबसे नीचे निर्माता/परिकल्पना क्रेडिट: रोहित पुंडी — राज्य कार्यालय प्रभारी, उत्तर प्रदेश पश्चिम। व्यक्तिगत फोटो शामिल नहीं है।

English app credit: Rohit Pundeer — State Office Incharge — Bharat Swabhiman Trust - UP West.

Visual refresh: premium saffron/forest-green theme, upgraded typography stack, animated hero seal, staggered category entrance, smoother card/button transitions, refined footer credit.
